PDF-Table
=========

Official repo for PDF::Table module collaboration.

https://github.com/kamenov/PDF-Table.git

Any patches, pull requests and feedback are more than welcome.

=======================
SOME NOTES

This module is intended for table generation using PDF::API2
The current version is RC1 and I will appreciate any feedback.
Developed and tested on i586 Linux SuSE 10.0 and Perl, v5.8.7 built for i586-linux-thread-multi

CHANGES

Since version 0.02 there are many changes. 
See the ChangeLog file or make a diff from the tools menu in CPAN

CONTACTS 

See http://search.cpan.org/~jbazik/

See http://search.cpan.org/~omega/

INSTALLATION

To install this module type the following:

   perl Makefile.PL
   make
   make test
   make install

DEPENDENCIES

This module requires these other modules and libraries:

  PDF::API2

COPYRIGHT AND LICENCE

Put the correct copyright and license information here.

Copyright (C) 2006 by Daemmon Hughes

Extended by Desislav Kamenov since version 0.02

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.7 or,
at your option, any later version of Perl 5 you may have available.


